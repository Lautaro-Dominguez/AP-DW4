

module.exports= {
    sumar: (nro1, nro2) => nro1 + nro2,
    restar: (nro1, nro2) => nro1 - nro2,
    multiplicar: (nro1, nro2) => nro1 * nro2,
    dividir: (nro1, nro2) => nro1 / nro2
    }