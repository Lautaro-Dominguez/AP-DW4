const calcular = require("./calculadora")

console.log( calcular.sumar(4, 2) )
console.log( calcular.restar(4, 2) )
console.log( calcular.multiplicar(4, 2) )
console.log( calcular.dividir(4, 2) )